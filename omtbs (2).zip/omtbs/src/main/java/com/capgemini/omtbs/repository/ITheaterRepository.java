package com.capgemini.omtbs.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.omtbs.entity.Movie;
import com.capgemini.omtbs.entity.Theatre;

@Repository
public interface ITheaterRepository extends JpaRepository<Theatre, Integer> {
	
	

	@Query(value = "SELECT m FROM Theatre t join t.listOfMovies m where t.theatreName= :theatreName")
	public List<Movie> findBytheaterName1(@Param("theatreName") String theatreName);

	
	@Query(value="SELECT m FROM Theatre t join t.listOfMovies m  where t.theatreCity= :theatreCity")
	public List<Movie> findBytheaterCity1(@Param("theatreCity") String theatreCity);


	@Query(value="select t.theatreCity from Theatre t")
	public List<String> findAllCities();

    @Query(value="select t.theatreName from Theatre t")
	public List<String> findAllTheatres();




//	@Query()
//	public List<Theatre> findAllByListOfMovies(@Param("theaterName") String theaterName);

}
