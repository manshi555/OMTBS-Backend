package com.capgemini.omtbs.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.omtbs.entity.Movie;
import com.capgemini.omtbs.entity.Theatre;

@Service
public interface ITheaterService {
	
	
	public List<Movie> searchMovieByTheater(String theatreName);
	
	public List<Movie> searchTheaterByMovie(String theatreCity);

}
