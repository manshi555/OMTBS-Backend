package com.capgemini.omtbs.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.omtbs.entity.Movie;
import com.capgemini.omtbs.entity.Theatre;
import com.capgemini.omtbs.repository.ITheaterRepository;

@Component
public class TheaterDaoImpl implements ITheaterDao {
	
	
	@Autowired
	ITheaterRepository theatreRepository;

	@Override
	public List<Movie> findMovieByTheaterName1(String theatreName) {
	
		return theatreRepository.findBytheaterName1(theatreName);
	}

	@Override
	public List<Movie> findTheatreByTheaterCity1(String theatreCity) {
		
		return theatreRepository.findBytheaterCity1(theatreCity);
	}


	
}
