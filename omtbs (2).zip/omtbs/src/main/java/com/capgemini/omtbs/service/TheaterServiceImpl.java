package com.capgemini.omtbs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.omtbs.dao.ITheaterDao;
import com.capgemini.omtbs.entity.Movie;
import com.capgemini.omtbs.entity.Theatre;
import com.capgemini.omtbs.repository.ITheaterRepository;

@Service
public class TheaterServiceImpl implements ITheaterService{
	
	
	
	@Autowired
	ITheaterDao theatreDao;
	
	@Autowired
	ITheaterRepository theaterRepository;

	@Override
	public List<Movie> searchMovieByTheater(String theatreName) {
		
		return theatreDao.findMovieByTheaterName1(theatreName);
	}

	@Override
	public List<Movie> searchTheaterByMovie(String theatreCity) {
		
		return theatreDao.findTheatreByTheaterCity1(theatreCity);
	}
	
	

}
