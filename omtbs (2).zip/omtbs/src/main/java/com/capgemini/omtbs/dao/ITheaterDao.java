package com.capgemini.omtbs.dao;

import java.util.List;

import com.capgemini.omtbs.entity.Movie;
import com.capgemini.omtbs.entity.Theatre;

public interface ITheaterDao {
	

public List<Movie> findMovieByTheaterName1(String theatreName);

public List<Movie> findTheatreByTheaterCity1(String theatreCity);
}
