package com.capgemini.omtbs.entity;
public enum BookingStatus {
	AVAILABLE, BOOKED, BLOCKED;
}
