package com.capgemini.omtbs.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.omtbs.entity.Movie;
import com.capgemini.omtbs.entity.Theatre;
import com.capgemini.omtbs.repository.ITheaterRepository;
import com.capgemini.omtbs.service.ITheaterService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(value="/theatre")
public class TheatreController {

@Autowired
ITheaterService theatreService;

@Autowired
ITheaterRepository theaterRepository;

@GetMapping("/getByTheatre/{theatreName}")
public List<Movie> searchMovieByTheater(@PathVariable(value="theatreName") String theatreName){
	return  theatreService.searchMovieByTheater(theatreName);
	
}

@GetMapping("/getAll")
public List<Theatre> getAll(){
	
	return (List<Theatre>) theaterRepository.findAll();
}

@GetMapping("/getByCity/{theatreCity}")
public List<Movie> searchMovierByCity(@PathVariable(value="theatreCity") String theatreCity)
{
	return  theatreService.searchTheaterByMovie(theatreCity);
	

}

@GetMapping("allCities")
public List<String> getAllCities(){
	return  theaterRepository.findAllCities();
}

@GetMapping("allTheatres")
public List<String> getAllTheatre()
{
	return theaterRepository.findAllTheatres();
}
}